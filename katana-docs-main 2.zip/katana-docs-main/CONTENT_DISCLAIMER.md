# Katana Documentation third-party content disclaimer

The Katana Documentation contains third-party content which includes websites, products, and services that are provided for informational purposes only.

Katana Services (Cayman) does not endorse, warrant, or make any representations regarding the accuracy, quality, reliability, or legality of any third-party websites, products, or services. If you decide to access any third-party content linked from the Katana Documentation, you do so entirely at your own risk and subject to the terms and conditions of use for such websites. Katana Services (Cayman) reserves the right to withdraw such references and links without notice.

The Katana Documentation serves as an industry public good and is made available under the MIT open source license. In addition, please view the official [Katana Services (Cayman) Terms of Use](https://katana.network/legal/terms-and-conditions/).