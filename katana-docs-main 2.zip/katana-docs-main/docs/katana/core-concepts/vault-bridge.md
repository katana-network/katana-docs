Productive TVL begins at the bridge level. Vault Bridge lets users deposit select assets into yield-generating wrappers and bridge them into Katana, where the yield is directed to the Katana ecosystem.
The initial set of vbTokens that users on Katana receive are vbUSDC, vbUSDS, vbUSDT, vbWBTC, and WETH.

WETH is a yield-generating vbToken that implements the WETH9 interface, serving as Katana's drop-in replacement for WETH9.
