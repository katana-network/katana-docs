### Full Brand Kit

[https://brand.katana.network](https://brand.katana.network)

### Social Icon

![](/img/katana/katana-social-icon.svg){width="150px"}

<a href="/img/katana/katana-social-icon.svg" target="_blank" rel="noopener noreferrer">Katana Social Icon.svg</a>

### Accent Colors

- Blue: #0550DB
- Yellow: #F6FF09
